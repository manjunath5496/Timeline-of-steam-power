function out=hn(n,x)

out=jn(n,x)+i*yn(n,x);
