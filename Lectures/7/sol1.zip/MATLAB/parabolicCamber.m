%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  parabolicCamber.m                                                   %%
%%  Propeller Parabolic Camber Line Generator                           %%
%%  M Jordan Stanway                                                    %%
%%  2.23 - Hydrofoils & Propellers                                      %%
%%  squall@mit.edu                                                      %%
%%  Created: 16 February 2006                                           %%
%%  Last Updated: 18 February 2006                                      %%
%%                                                                      %%
%%  All rights reserved                                                 %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Help goes here...

function [f,theta_dfdx] = parabolicCamber(F0_C,C_D,D,numPoints);

% Create non-dimensional f(x) given F0_C for a particular cross-section %%%
C  = C_D  * D;
F0 = F0_C * C;
x  = [-0.5:(1/numPoints):0.5]*C;

f          = F0 * (1-(2*x/C).^2);
theta_dfdx = atan2(-8*F0*x/C^2,1);

