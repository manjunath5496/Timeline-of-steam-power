%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  trapezoidal.m                                                          %
%  Trapezoidal Rule Numerical Integration Function                        %
%  Created by : Brenden  Epps,    bepps@mit.edu,  7 March 2007            %
%  2.23 - Hydrofoils & Propellers                                         %
%                                                                         %
%  All rights reserved                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Trapezoidal_integral = trapezoidal(fun,a,b,n)
% Numerical integration using Trapezoidal Rule
% fun - string input for function y = f(x) (e.g. f = 'x.^6')
% a   - lower limit of integration
% b   - upper limit of integration
% n   - number of divisions
%
% Example: 
% trapezoidal('(1-x).*exp(-x)',0,5,10)
%
% Actual functions F = integral(f)
% F =    x .*exp(-x);
% f = (1-x).*exp(-x);

%%%%%%%%%%%%%  Numerical Integration        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delta_x = (b-a)/n;              % x spacing
x       = a : delta_x : b;      % x coordinates

f       = eval(fun);      % function to be integrated

%%%  Trapezoidal method  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i = 1:n
    area_of_each_trapezoid(i) = (1/2)*(f(i)+f(i+1))*delta_x;
end

Trapezoidal_integral = sum(area_of_each_trapezoid);
