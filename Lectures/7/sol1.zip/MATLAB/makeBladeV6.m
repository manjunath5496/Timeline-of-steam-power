%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  makeBladeV6.m                                                          %
%  Propeller Blade Generator                                              %
%  Created by : M Jordan Stanway, squall@mit.edu, 29 November 2006        %
%  Last Update: Brenden  Epps,    bepps@mit.edu,   7 March    2007        %
%  2.23 - Hydrofoils & Propellers                                         %
%                                                                         %
%  All rights reserved                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Before using this script, make sure you have the following functions:
%   parabolicCamber.m
%   ellipticalThickness.m
% Also, make sure this is the directory structure you have:
%   <Project Directory>
%       bladeCoords
%           - output files to be used in CAD programs
%       MATLAB
%           - makeBladeV3.m
%           - makeXsec.m
%           - parabolicCamber.m
%           - ellipticalThickness.m
%       propParams
%           - blade_geometry.dat
%           - input files of propeller geometry
%           
% geometryFile is a .dat text file with non-dimensional values in columns:
% R/Ro  P/D     xs/d   Skew (deg)    C/D       Fo/c     To/D
%
% blade_geometry.dat is an example
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all; close all;
set(0,'DefaultFigureWindowStyle','docked') 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Size the propeller outer diameter %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
D = 1;      % initialize as 1 [m], makeBlade will scale later                      
R = D/2;    % propeller radius, [m]

%%% Read in propeller parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cd ../propParams
dir
prop_name = input('Propeller geometry file [blade_geometry]: >>> ','s');
    if isempty(prop_name)
        prop_name = 'blade_geometry';
    end
geometryFile = [prop_name '.dat'];
[r_R,P_D,rake,skew_deg,C_D,F0_C,T0_D] = textread(geometryFile,'%f%f%f%f%f%f%f','headerlines',1); % non-dimensional parameters
radius = r_R * R;               % radius of each section, [m]
skew_rad = skew_deg*pi/180;     % skew   of each section, [rad]

numSections = length(r_R);
disp(sprintf('Propeller geometry file %s has %d sections...',prop_name,numSections));
cd ../MATLAB

%%%% Ask how fine the mesh should be %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
numPoints = input('How many points should be on each surface? [42] >>> ');
    if isempty(numPoints)
        numPoints = 42;
    end
    
%%%% Ask how many blades are on the propeller %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
numBlades = input('How many blades are on the propeller? [3] >>> ');
    if isempty(numBlades)
        numBlades = 3;
    end
theta_Blades = 2*pi/numBlades * [0:1:numBlades-1];

%%%% Ask if you want to output CAD data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
doCAD = input('Output CAD data [y/n]? [n] >>> ','s');
    if isempty(doCAD)
        doCAD = 'n';
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%% Generate cross-section profiles %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure('Name','cross section profiles'); title('Cross section profiles');
for section = 1:numSections
    [x_sec_X x_sec_Y] = makeXsec(geometryFile,section,numPoints);
    
    localChord (section,:) = x_sec_X;
    localHeight(section,:) = x_sec_Y;
    
    if numSections < 13
        subplot(4,round(numSections/4),section);
        plot(x_sec_X, x_sec_Y,'LineWidth',2);
        grid on;
        %axis([-0.2 0.2 -0.06 0.06]);
        axis equal;
        title(sprintf('r/R_0 = %f',r_R(section)));
    end    
end

%%%% Rotate cross-section profiles for pitch %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure('Name','pitched cross section profiles');
for section = 1:numSections
    P_ang(section) = atan((P_D(section)*D)/(2*pi*radius(section)));

    localChord(section,:) =  localChord(section,:)*cos(P_ang(section))+localHeight(section,:)*sin(P_ang(section));
    localHeight(section,:)= -localChord(section,:)*sin(P_ang(section))+localHeight(section,:)*cos(P_ang(section));
    
    if numSections < 13
        subplot (4,round(numSections/4),section);
        plot(localChord(section,:), localHeight(section,:),'LineWidth',2);
        grid on;
        %axis([-0.2 0.2 -0.06 0.06]);
        axis equal;
        title(sprintf('r/R_0 = %f',r_R(section)));
    end
end

%%%% Wrap cross section profiles to the radius & invoke skew, generate
%%%% datapoints for multiple blades
for section=1:numSections
    phi = localChord(section,:)/radius(section);
    
    localChord(section,:) = radius(section)*sin(phi + skew_rad(section));    
    localSpan (section,:) = radius(section)*cos(phi + skew_rad(section));
    
    for blade = 1:numBlades
        LocalChord(section,:,blade) = radius(section)*sin(phi + skew_rad(section) + theta_Blades(blade));
        LocalSpan (section,:,blade) = radius(section)*cos(phi + skew_rad(section) + theta_Blades(blade));
    end
end

%%%% Invoke rake of the-cross section %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for section=1:numSections
    localHeight(section,:) = localHeight(section,:) - rake(section)/D;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Plot cross section profiles %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure('Name','cross section profiles wrapped, skewed, and raked')
    subplot(1,2,1)
        hold on;
        for section=1:numSections
            hold on;
            plot3(localChord (section,:),localSpan(section,:),...
                  localHeight(section,:) );
        end
        title('front view of cross sections')
    subplot(1,2,2)
        hold on;
        for section=1:numSections
            plot3(localChord (section,:),localSpan(section,:),...
                  localHeight(section,:) );
        end
        title('end-on view of sections');
        view(0,0)
        
%%%% Plot surface of single blade %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure('Name','single propeller blade')
    Xsurf = permute(localChord ,[2 1]);
    Ysurf = permute(localSpan  ,[2 1]);
    Zsurf = permute(localHeight,[2 1]); 
    subplot(1,2,1)
        surfl(Xsurf(:,:,1),Zsurf,Ysurf(:,:,1))
        shading interp
        colormap(winter);
        axis image
        title('view from behind blade')
        view(180,-90)    
    subplot(1,2,2)
        surfl(Xsurf,Zsurf,Ysurf)
        shading interp
        colormap(winter);
        axis image
        title('view from front of propeller')
        view(0,0)
        
%%%% Plot blades of a full propeller %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure('Name',sprintf('%d propeller blades',numBlades))
    hold on;
    Xsurf = permute(LocalChord,[2 1 3]);
    Ysurf = permute(LocalSpan,[2 1 3]);
    Zsurf = permute(localHeight,[2 1 3]);
    for blade=1:numBlades
        surfl(Xsurf(:,:,blade),Zsurf(:,:),Ysurf(:,:,blade))
    end
    shading interp
    colormap(copper);
    axis image
    title('view from front of propeller')
    view(180,0)

    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%%%% Output CAD model of a full propeller %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
if doCAD == 'y'   
    %%%% Output text files of each section that can be read in by a CAD program
    Diam = input('What diameter propeller should I output files for CAD? [4.5 in] >>>  ');
    if isempty(Diam)
        Diam = 4.5;
    end
    hubRad = Diam/2*r_R(1);
    hubLength = input('What hub length should be included in CAD? [1 in] >>>  ');
    if isempty(hubLength)
        hubLength = 1;
    end
    cd ../bladeCoords
    fid = fopen([prop_name '-RhinoFull.txt'],'w');
        fprintf(fid,'! ');
    for section=1
        fprintf(fid,'Curve \n');        % ! do we want it by control points or though an interpolation?
        for j=1:length(localChord(section,:))
            fprintf(fid,'%f,%f,%f\n',Diam*localChord(section,j),...
                0.95*Diam*localSpan(section,j),Diam*localHeight(section,j) );
        end
    end
    for section=2:numSections
        fprintf(fid,'Curve \n');
        for j=1:length(localChord(section,:))
            fprintf(fid,'%f,%f,%f\n',Diam*localChord(section,j),...
                Diam*localSpan(section,j),Diam*localHeight(section,j) );
        end
    end
    fprintf(fid,'SelNone\n');
    fprintf(fid,'SelLast\n');
    fprintf(fid,'-Patch\n');
    fprintf(fid,'USpans=10\n');
    fprintf(fid,'VSpans=10\n');
    fprintf(fid,'Stiffness=0.0001\n');
    fprintf(fid,'AutomaticTrim=Yes\n');
    fprintf(fid,'enter\n');
    fprintf(fid,'SelNone\n');
    fprintf(fid,'SelCrv\n');
    fprintf(fid,'-Loft Tight RebuildCount=10\n');
    fprintf(fid,'enter\n');
    fprintf(fid,'enter\n');
    fprintf(fid,'SelNone\n');
    fprintf(fid,'SelCrv\n');
    fprintf(fid,'Delete\n');
    fprintf(fid,'SelAll\n');
    fprintf(fid,'Join\n');
    fprintf(fid,'SelLast\n');
    fprintf(fid,'Rotate\n');
    fprintf(fid,'Copy=Yes\n');
    fprintf(fid,'0,0,0\n');
    for blade=2:numBlades
    fprintf(fid,'%f\n',(blade-1)*(360/numBlades));
    end
    fprintf(fid,'enter\n');
    fprintf(fid,'Circle\n');
    fprintf(fid,'0,0,0\n');
    fprintf(fid,'%f\n',hubRad);
    fprintf(fid,'SelNone\n');
    fprintf(fid,'SelLast\n');
    fprintf(fid,'ExtrudeCrv BothSides=Yes Cap=Yes DeleteInput=Yes\n ');
    fprintf(fid,'%f\n',hubLength/2);
    fprintf(fid,'enter\n');
    fprintf(fid,'Zoom All Extents\n');
    fprintf(fid,'enter\n');
    fclose(fid);

    fid = fopen([prop_name '-RhinoBlade.txt'],'w');
        fprintf(fid,'! ');
    for section=1
        fprintf(fid,'Curve \n');        % ! do we want it by control points or though an interpolation?
        for j=1:length(localChord(section,:))
            fprintf(fid,'%f,%f,%f\n',Diam*localChord(section,j),...
                0.95*Diam*localSpan(section,j),Diam*localHeight(section,j) );
        end
    end
    for section=2:numSections
        fprintf(fid,'Curve \n');
        for j=1:length(localChord(section,:))
            fprintf(fid,'%f,%f,%f\n',Diam*localChord(section,j),...
                Diam*localSpan(section,j),Diam*localHeight(section,j) );
        end
    end
    fprintf(fid,'SelNone\n');
    fprintf(fid,'SelLast\n');
    fprintf(fid,'-Patch\n');
    fprintf(fid,'USpans=10\n');
    fprintf(fid,'VSpans=10\n');
    fprintf(fid,'Stiffness=0.0001\n');
    fprintf(fid,'AutomaticTrim=Yes\n');
    fprintf(fid,'enter\n');
    fprintf(fid,'SelNone\n');
    fprintf(fid,'SelCrv\n');
    fprintf(fid,'-Loft Tight RebuildCount=10\n');
    fprintf(fid,'enter\n');
    fprintf(fid,'enter\n');
    fprintf(fid,'SelNone\n');
    fprintf(fid,'SelCrv\n');
    fprintf(fid,'Delete\n');
    fprintf(fid,'SelAll\n');
    fprintf(fid,'Join\n');
    fprintf(fid,'SelNone\n');
    fprintf(fid,'Circle\n');
    fprintf(fid,'0,0,0\n');
    fprintf(fid,'%f\n',hubRad);
    fprintf(fid,'SelNone\n');
    fprintf(fid,'SelLast\n');
    fprintf(fid,'ExtrudeCrv BothSides=Yes Cap=Yes DeleteInput=Yes\n ');
    fprintf(fid,'%f\n',hubLength/2);
    fprintf(fid,'SelNone\n');
    fprintf(fid,'SelLast\n');
    fprintf(fid,'BooleanUnion\n');
    fprintf(fid,'SelAll\n');
    fprintf(fid,'enter\n');
    fprintf(fid,'Zoom All Extents\n');
    fprintf(fid,'enter\n');

    fclose(fid);

    cd ../MATLAB
    disp([prop_name ' Rhino script files created.']) 
    disp('Please open Rhino3d with a new (inches) document.')
    disp('Use ReadCommandFile to generate the propeller.')
end