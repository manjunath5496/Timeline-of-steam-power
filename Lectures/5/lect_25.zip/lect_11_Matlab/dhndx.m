function out=dhndx(n,x)

out=hn(n-1,x)-(n+1)*hn(n,x)/x;
