% Plots Legendre Polynomials (m=0) up to order 5.   

N=5; 				

theta=0:.01:pi;
cols=floor(sqrt(N));
rows=ceil(N/cols);

figure(1);

for n=0:N
	L=legendre(n,cos(theta));
   subplot(rows,cols,n+1);
   plot(theta,L(1,:));
   axis([0,pi,-1,1]);
   title(sprintf('n=%d',n))
   %xlabel('\theta');
   ylabel('P_n');
   grid on
end

orient tall;



