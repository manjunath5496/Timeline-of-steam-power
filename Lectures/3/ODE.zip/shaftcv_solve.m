function [t,omega]=shaftcv_solve(J,f_v,f_c,T_s,t_max,omega_0)

[t,omega]=ode45(@(t,w) shaftcv_kernel(t,w,J,f_v,f_c,T_s),[0 t_max],omega_0);