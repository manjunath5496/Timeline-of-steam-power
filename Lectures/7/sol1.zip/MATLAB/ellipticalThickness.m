%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  ellipticalThickness.m                                               %%
%%  Propeller Elliptical Thickness Profile Generator                    %%
%%  M Jordan Stanway                                                    %%
%%  2.23 - Hydrofoils & Propellers                                      %%
%%  squall@mit.edu                                                      %%
%%  Created: 16 February 2006                                           %%
%%  Last Updated: 18 February 2006                                      %%
%%                                                                      %%
%%  All rights reserved                                                 %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Uses elliptical thickness form

function [t] = thickness(T0_D_i,C_D_i,D,numPoints);

% Create non-dimensional t(x) given T0_D_i for a particular cross-section
T0 = T0_D_i * D;
C  =  C_D_i * D;
x  = [-0.5:(1/numPoints):0.5]*C;

t  = T0 * sqrt(1-(2*x/C).^2);