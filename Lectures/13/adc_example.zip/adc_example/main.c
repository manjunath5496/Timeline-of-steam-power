/*
--------------------------------------------------------------
2.996 / 6.971: Biomedical Devices Design Laboratory
Lab Example Software - ADC

This example continuously sample analog input channels
12 through 15 (pins 4.3-4.6), subtracts a calibration offset,
and stores the results in an array.

SC - 9/30/2007
--------------------------------------------------------------
*/

#include "msp430x22x4.h"

void main(void)
{ 
  // stop watchdog timer
  WDTCTL = WDTPW | WDTHOLD;
  
  // array to store ADC conversion results
  signed int adc_result[4] = {0, 0, 0, 0};
  // zero references
  signed int center[4] = {511, 516, 508, 509};
  // for loop
  unsigned char i;
  
  // Clock Setup:
  // -----------------------------------------------------
  // XT2 not used, LFXT1 set to high-frequency mode
  // no divider for ACLK (full 16MHz)
  BCSCTL1 = XT2OFF | XTS;
  // set MCLK as LFXT1 (16MHz), no divider
  // also set SMCLK as LFXT1, but divide by 4 (4MHz)
  BCSCTL2 = SELM1 | SELM0 | SELS | DIVS1;
  // set LFXT1 to 3-16MHz range
  BCSCTL3 = LFXT1S1;
  // See User's Guide, 5-14 thru 5-16.
  // -----------------------------------------------------
  
  // ADC Setup:
  // -----------------------------------------------------
  // set and output 2.5V reference, turn on ADC
  ADC10CTL0 = SREF0 | REFOUT | REF2_5V | REFON | ADC10ON;
  // use ACLK, 16MHz, for conversion timing
  ADC10CTL1 = ADC10SSEL0;
  // enable A12-A15 as analog inputs
  ADC10AE1 = 0xF0;
  // See User's Guide, 20-25 thru 20-29.
  // -----------------------------------------------------
  
  while(1) // loop forever
  {
    // loop through channels A12-A15
    for(i = 0; i <= 3; i++)
    {
      // mask ADC10CTL1 lower 12 bits and set INCH bits
      // See User's Guide, 20-27.
      ADC10CTL1 = (ADC10CTL1 & 0xFFF) | ((12 + i) << 12);
      // enable ADC and start conversion
      ADC10CTL0 |= ENC | ADC10SC;
      // wait for conversion to be finished
      while((ADC10CTL1 & ADC10BUSY) != 0);
      // subtract offset and store result
      adc_result[i] = ADC10MEM - center[i];
      // end conversion and setup for next trigger
      ADC10CTL0 &= ~(ENC | ADC10SC);
    }
  }  
}
