function o=fctrl_rc(n)
%
% Problem 5.1 :	Calculating the factorial of non-negative integer with recursion
%

if n==0
    o=1;            % fctrlrc(0)=1
else
    o=n*fctrlrc(n-1); % Use recursion
end