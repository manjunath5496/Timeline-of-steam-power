%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  pset3_prob1.m                                                          %
%  (see problem set 3)                                                    %
%                                                                         %
%  Created by: Brenden  Epps,     bepps@mit.edu, 7 March 2007             %
%  2.23 - Hydrofoils & Propellers                                         %
%                                                                         %
%  All rights reserved                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all, clear,

s     = 1;
gamma = 1;

P = [0, -s/4, 0;...  % points are arranged in [x y z] by row 
     0,    0, 0;...  % i_P is the index telling what row to use
     0,  s/4, 0];

theta_deg = 10 : 10 : 60; 
theta     = theta_deg*pi/180; 

x_B2 = -1*(s/2)./tan(theta);

P_A1 = [1000*s -s/2 0];
P_A2 = [0 -s/2 0];

P_B1 = P_A2;
P_B2 = [x_B2' zeros(length(x_B2),1) zeros(length(x_B2),1)]; % points by row, i_theta is the index telling what row to use

P_C1 = P_B2;
P_C2 = [0 s/2 0];

P_D1 = P_C2;
P_D2 = [1000*s s/2 0];


%%%  Calculation of velocity vector at point P due to vortex  %%%%%%%%%%%%%
for i_theta = 1:length(theta)
    for i_P = 1:3
        V_A = induced_velocity(P(i_P,:), P_A1           , P_A2           , gamma);
        V_B = induced_velocity(P(i_P,:), P_B1           , P_B2(i_theta,:), gamma);
        V_C = induced_velocity(P(i_P,:), P_C1(i_theta,:), P_C2           , gamma);
        V_D = induced_velocity(P(i_P,:), P_D1           , P_D2           , gamma);
        
        V(i_theta,:,i_P) = V_A' + V_B' + V_C' + V_D';
    end
end

V
