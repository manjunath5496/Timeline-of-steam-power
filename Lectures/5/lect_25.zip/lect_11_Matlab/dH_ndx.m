function out=dH_ndx(n,x)

out=n/x*H_n(n,x)-H_n(n+1,x);
