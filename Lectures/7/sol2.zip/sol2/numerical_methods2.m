%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  numerical_methos.m                                                     %
%  Numerical Methods Example                                              %
%  Created by : Brenden  Epps,    bepps@mit.edu,  19 February 2007        %
%  2.23 - Hydrofoils & Propellers                                         %
%                                                                         %
%  All rights reserved                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear, close all, clc,
set(0,'DefaultFigureWindowStyle','docked') 

%%%%%%%%%%%%%  Numerical Differentiation    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delta_x = 1;
x       = 0:delta_x:5;
n       = length(x);

F     =     x .*exp(-x);
f     =  (1-x).*exp(-x);
f_p   = (-2+x).*exp(-x);

X     = 0:0.01:5;
F_X   =     X .*exp(-X);
f_X   =  (1-X).*exp(-X);
f_p_X = (-2+X).*exp(-X);

% F     =                   cos(x).*exp(-x)-1;
% f     =  -sin(x).*exp(-x)-cos(x).*exp(-x);
% f_p   = 2*sin(x).*exp(-x);
% 
% X     = 0:0.01:5;
% F_X   =                   cos(X).*exp(-X)-1;
% f_X   =  -sin(X).*exp(-X)-cos(X).*exp(-X);
% f_p_X = 2*sin(X).*exp(-X);


%%% Forward divided difference %%%
for i = 1:n-1
  f_p_forward(i)  = (f(i+1)-f(i))/delta_x;
end
f_p_forward(n)=NaN;

%%% Backward divided difference %%%
f_p_backward(1)=NaN;
for i = 2:n
  f_p_backward(i) = (f(i)-f(i-1))/delta_x;
end

%%% Central divided difference %%%
f_p_central(1)=NaN;
for i = 2:n-1
  f_p_central(i)  = (f(i+1)-f(i-1))/(2*delta_x);
end
f_p_central(n)=NaN;


% %%% The forward and backward divided difference formulas are basically the
% %%% same, except the index is shifted one point over.
% [f_p' f_p_forward' f_p_backward' f_p_central']
% 
% %%% Another way of computing f_p_forward is this:
% f_p_forward_alt    = diff(f)/delta_x;
% f_p_forward_alt(n) = NaN;
% 
% [f_p_forward'-f_p_forward_alt']
% 
% %%% Another way of computing f_p_central is this:
% f_p_central_alt(1)     = NaN;
% f_p_central_alt(2:n-1) = (f_p_forward(2:n-1)+f_p_backward(2:n-1))/2;
% f_p_central_alt(n)     = NaN;
% 
% [f_p_central'-f_p_central_alt']

figure
plot(X,f_X,'b',x,f,'sk'), xlabel('x'), ylabel('f(x)'), title('f(x)')

figure
plot(X,f_X,'b',x,f,'sk',x,f,'k'), xlabel('x'), ylabel('f(x)'), title('f(x)')

figure
plot(X,f_p_X,'b',x,f_p_central,'ks'), xlabel('x'), ylabel('f_p(x)'), title('f_p(x)')


%%%%%%%%%%%%%  Numerical Integration        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% delta_x = 1;
% x       = 0:delta_x:5;
% n       = length(x);
% 
% F     =     x .*exp(-x);
% f     =  (1-x).*exp(-x);
% f_p   = (-2+x).*exp(-x);
% 
% X     = 0:0.01:5;
% F_X   =     X .*exp(-X);
% f_X   =  (1-X).*exp(-X);
% f_p_X = (-2+X).*exp(-X);

%%% Trapezoidal method %%%
for i = 1:n-1
    area_of_each_trapezoid(i) = (1/2)*(f(i)+f(i+1))*delta_x;
end

F_trapezoidal(1)   = 0;
F_trapezoidal(2:n) = cumsum(area_of_each_trapezoid);

figure
plot(X,F_X,'b',x,F_trapezoidal,'ks'), xlabel('x'), ylabel('F'), title('F')


%%% Alternate implementation of Trapezoidal method %%%
F_trapezoidal_alt(1) = 0;
F_trapezoidal_alt(2) = (1/2)*(f(1)+f(2))*delta_x;
for i = 3:n-1
F_trapezoidal_alt(i) = ((1/2)*(f(1)+f(i+1))+sum(f(2:i)))*delta_x;
end




