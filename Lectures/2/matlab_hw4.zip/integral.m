function integral
%
% Problem 4.2 :	Integrating two functions numerically over the interval with function handler
%

% First method

P=@(x)x.^2+2*x+3;       % Define Polynomial function given at 4.2 i)
quad(P,1,10)            % Integrate function from 1 to 10
G=@(x)1/sqrt(2*pi)*exp(-(x/sqrt(2)).^2);    % Define Gaussian function given at 4.2 ii)
quad(G,-10^10,10^10)                        % Integrate function from -10^10 (almost -infinity) to 10^10 (almost +infinity)

% Second method
disp(sprintf('Intrgral from 1 ro 10 for x^2+2x+3 is %f',quad(@Polynomial,1,10)));
disp(sprintf('Intrgral from -inf to +inf exp(-((x)/(sqrt(2)*c))^2)is %20.15f',quad(@Gaussian,-10^10,10^10)));

function y=Polynomial(x)
a=1; b=2; c=3;
y=a*x.^2+b*x+c;

function y=Gaussian(x)
a=1/sqrt(2*pi); b=0; c=1;
y=a*exp(-((x-b)/(sqrt(2)*c)).^2);
