function[UsA,UsT] = helix(rc, rv,gamma, z, Bw)
    if rc < rv
        UsA = gamma*z/(4*pi*rv*tand(Bw));
        UsT = 0;
    elseif rc>rv
        UsA = 0;
        UsT = gamma*z/(4*pi*rc);
    end