function out=Ymn(m,n,theta,phi)

Pfun=legendre(n,cos(theta));

if n==0
   Pmn=squeeze(Pfun);
else
   switch ndims(theta)
   case 1
      Pmn=squeeze(Pfun(m+1,:));
	case 2
   	Pmn=squeeze(Pfun(m+1,:,:));
   end
end

out=sqrt((2*n+1)/4/pi*factorial(n-m)/factorial(n+m)).*Pmn.*exp(i*m.*phi);
