%Returns velocity induced (axial and tangential) on a point on a lifting line due to a helical vortex
%of an infinite bladed propeller (eq's 206 and 207 in notes)

function [U_bar_axial, U_bar_tangential] = helix(rc,rv,Z,betaW)
    %rc    = [m],     radius on lifting line for which velocity is evaluated
    %rv    = [m],     radius of helical vortex
    %gamma = [m^2/s], helical vortex strength
    %Z     = [ ],     number of blades
    %betaW = [deg],   pitch angle of helical wake trail

y  = rc/(rv*tand(betaW));
y0 = 1/tand(betaW);
U  = ((y0*(sqrt(1+y ^2)-1))*exp(sqrt(1+y^2)-sqrt(1+y0^2))/...
      (y *(sqrt(1+y0^2)-1)))^Z;

F1 = -(1/(2*Z*y0)) * ((1+y0^2)/(1+y^2))^0.25 * ...
     ((1/(U^-1-1)) + (1/(24*Z))*...
     (((9*y0^2+2)/(1+y0^2)^1.5)+((3*y^2-2)/(1+y^2)^1.5))*...
      log(abs(1+(1/(U^-1-1)))) );

F2 = -(1/(2*Z*y0)) * ((1+y0^2)/(1+y^2))^0.25 * ...
     ((1/(U-1))    - (1/(24*Z))*...
     (((9*y0^2+2)/(1+y0^2)^1.5)+((3*y^2-2)/(1+y^2)^1.5))*...
      log(abs(1+(1/(U-1)))) );
  
if rc == rv
    U_bar_axial      = NaN;
    U_bar_tangential = NaN;
    
elseif rc < rv        
    U_bar_axial      = (Z  /(4*pi*rc))*(y-2*Z*rv*F1);
    U_bar_tangential = (Z^2/(2*pi*rc))*(y0*F1);

elseif rc > rv
    U_bar_axial      = -(Z^2/(2*pi*rc))*(y*y0*F2);
    U_bar_tangential =  (Z  /(4*pi*rc))*(1+2*Z*y0*F2);
    
end


% function[UsA,UsT] = helix(rc, rv,gamma, z, Bw)
%     if rc < rv
%         UsA = gamma*z/(4*pi*rv*tand(Bw));
%         UsT = 0;
%     elseif rc>rv
%         UsA = 0;
%         UsT = gamma*z/(4*pi*rc);
%     end