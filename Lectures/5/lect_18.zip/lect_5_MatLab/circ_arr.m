%
% MATLAB script for plotting the directivity function for
% an array of circular, baffled pistons
%
% Parameters:
% k     Wavenumber
% rho   Density
% c     Speed of Sound
% a     Radius of piston of piston
% d     Piston separation
% nd    Number of pistons
% qd    Array of piston strengths

clear
figure(1)
hold off
k=10.0;
rho=1000;
c=1500;
a=1.0;

% Half wavelength spacing, d= pi/k
d=pi/k;
nd=10;
ah=(nd-1)*d/2

xd=[-ah:d:ah]';
kxd_0=k/2;
qd=ones(length(xd),1);
qd=exp(-i*kxd_0*xd);
%qd(2)=-1;

ka=k*a;

figure(1);
kxm=2*ka;
nkx=300;
dkx=2*kxm/(nkx-1);
x=[-kxm:dkx:kxm];
y=x;
o=ones(1,nkx);
kx=x' * o;
ky=(y' *o)';
kr=abs(complex(kx,ky));

    kx1=reshape(kx,1,nkx^2);
    shd=qd'*exp(-i*xd*kx1);
    shd=reshape(shd,nkx,nkx);

ss=rho*k*c*a^2 * besselj(1,kr)./kr;
%surfc(kx,ky,dba(ss));
wavei(dba(ss.*shd)',x,y)
shading('flat')
axis('equal')
b=xlabel('k_x a')
set(b,'FontSize',16);
b=ylabel('k_y a')
set(b,'FontSize',16);
tit=['Circular Piston Array - ka = ' num2str(k*a) ' - d,n =' num2str(d) ', '  num2str(nd) ]

b=title(tit);
set(b,'FontSize',20);
nphi=361;
dphi=2*pi/(nphi-1);
phi=[0:dphi:2*pi];
xx=k*a*cos(phi);
yy=k*a*sin(phi);
hold on
b=plot(xx,yy,'b');
set(b,'LineWidth',3);


figure(2) 
nphi=361.
dphi=2*pi/(nphi-1)
nth=181;
dth=0.5*pi/(nth-0.5);

phi=[0:dphi:(nphi-1)*dphi]' * ones(1,nth);
th=([dth/2:dth:pi/2]'*ones(1,nphi))';
kx=ka*sin(th).*cos(phi);
ky=ka*sin(th).*sin(phi);
kr=ka*sin(th);
ss=rho*k*c*a^2*besselj(1,kr)./kr;

    kx1=reshape(kx,1,size(kx,1)*size(kx,2));
    shd=qd'*exp(-i*xd*kx1);
    shd=reshape(shd,size(kx,1),size(kx,2));

ss=dba(ss.*shd);
sm=max((max(ss))');
for i=1:size(ss,1)
     for j=1:size(ss,2)
     ss(i,j)=max(ss(i,j),sm-40.0)-(sm-40.0);
end
end

xx=ss.*sin(th).*cos(phi);
yy=ss.*sin(th).*sin(phi);
zz=ss.*cos(th);

surfl(xx,yy,zz);
colormap('copper');
shading('flat');
axis('equal');
tit=['Circular Piston Array - ka = ' num2str(k*a) ' - d,n =' num2str(d) ', ' num2str(nd) ]
b=title(tit);
set(b,'FontSize',20);


figure(3)
b=polar([pi/2-fliplr(th(1,:)) pi/2+th((nphi-1)/2+1,:)],[fliplr(ss(1,:)) ss((nphi-1)/2+1,:)]); 
set(b,'LineWidth',2)
tit=['Circular Piston Array - ka = ' num2str(k*a) ' - d,n =' num2str(d) ', ' num2str(nd) ]

b=title(tit);
set(b,'FontSize',20);


