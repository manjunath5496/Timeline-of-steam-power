function [s,d,ep,mp]=bop(A,B)
%
% Problme 4.1:	Writing a function to perform multiple matrix operations
%
% Input arguments: two same size matrices
% Output arguments: sum(s), difference(d), element by element product(ep)
%                   and matrix product(mp) of two matrices
%

% sum of two matrices
s=A+B;
% difference of two matrices
d=A-B;
% element-by-element product of two matrices
ep=A.*B;
% matrix product of two matrices
mp=A*B;