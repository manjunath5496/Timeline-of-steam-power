******************************** README.TXT ********************************

MAIN MATLAB FILES USED IN CLASS

sharm.m		Visualization of various spherical harmonic functions.
monopole.m	Visualization of particle displacement around a monopole.
dipole.m	Simulation of particle displacement around dipole.
hard_sphere.m	Scattering of a plane wave from a hard sphere.
soft_sphere.m	Scattering of a plane wave from a soft sphere.
helical.m	Visualization of helical wave propagation.
cylrad.m	Visualization of radiation from a cylinder for kz=0.

SUPPORT FILES

lpoly.m		Plots some Legendre polynomials.
Ymn.m		Single spherical harmonic evaluations.
hn.m		Spherical Hankel functions.
jn.m		Spherical Bessel functions (of the first kind).
yn.m		Spherical Bessel functions (of the second kind).
dhndx.m		Derivatives of spherical Hankel functions.
djndx.m		Derivatives of spherical Bessel functions.
H_n.m		Hankel functions.
dH_ndx.m	Derivatives of Hankel functions.


****************************************************************************




