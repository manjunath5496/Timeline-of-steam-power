%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  trapezoidal.m                                                          %
%  Trapezoidal Rule Numerical Integration Example                         %
%  Created by : Brenden  Epps,    bepps@mit.edu,  7 March 2007            %
%  2.23 - Hydrofoils & Propellers                                         %
%                                                                         %
%  All rights reserved                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear, close all, clc,
set(0,'DefaultFigureWindowStyle','docked') 
set(0,'defaultaxesfontsize',14);
linewidth = 1.1;

%%%%%%%%%%%%%  Numerical Integration        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
a       = 0;                    % lower limit of integral
b       = 5;                    % upper limit of integral
n       = 56;                   % number of divisions

delta_x = (b-a)/n;              % x spacing
x       = a : delta_x : b;      % x coordinates

F       =     x .*exp(-x);      % exact solution of the integral
f       =  (1-x).*exp(-x);      % function to be integrated

%%%  Find f and F with small delta_x to make the plots look pretty  %%%%%%%
X       = a: (b-a)/100 : b;     % x coordinates with small spacing
F_X     =     X .*exp(-X);      % exact solution of the integral
f_X     =  (1-X).*exp(-X);      % function to be integrated

%%%  Trapezoidal method  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i = 1:n
    area_of_each_trapezoid(i) = (1/2)*(f(i)+f(i+1))*delta_x;
end

F_trapezoidal(1)   = 0;
F_trapezoidal(2:n+1) = cumsum(area_of_each_trapezoid);

%%% Alternate implementation of Trapezoidal method %%%
F_trapezoidal_alt(1)     = 0;
F_trapezoidal_alt(2)     = (1/2)*(f(1)+f(2))*delta_x;
for i = 3:n-1
    F_trapezoidal_alt(i) = ((1/2)*(f(1)+f(i+1))+sum(f(2:i)))*delta_x;
end


%%%  Plot the results  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure('Name','function'), hold on,
    plot(X,f_X,'b',x,f,'ks','LineWidth',linewidth), 
    plot(x,f,'k')
    xlabel('x','Fontsize',14), ylabel('function, f(x)','Fontsize',14), 
    title('Function to be Integrated','Fontsize',16)

figure('Name','integral')
    plot(X,F_X,'b',x,F_trapezoidal,'ks','LineWidth',linewidth), 
    xlabel('x','Fontsize',14), ylabel('Integral from a to x, F(x)','Fontsize',14), 
    title('Trapezoidal Rule Numerical Integration','Fontsize',16)

