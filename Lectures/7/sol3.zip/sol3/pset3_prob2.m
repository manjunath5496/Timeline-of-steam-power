%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  pset3_prob2.m                                                          %
%  (see problem set 3)                                                    %
%                                                                         %
%  Created  by: Chris Peterson, cjpeters@mit.edu, 16 March 2007           %
%  Modified by: Brenden  Epps,     bepps@mit.edu, 20 March 2007           %
%  2.23 - Hydrofoils & Propellers                                         %
%                                                                         %
%  All rights reserved                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear, close all,

a1 = 0.005;
a3 = -0.02:0.01:0.02;
s  = 1;
U  = 8;
density = 998;

y_tilda = 0:(pi/100):pi;
y       = -s/2 * cos(y_tilda);

for i = 1:5
    circ(i,:)   = 2*U*s*(a1*sin(y_tilda) + a3(i)*sin(3*y_tilda));
    
    w_star(i,:) = -U*(a1 + 3*a3(i)*sin(3.*y_tilda)./sin(y_tilda));
end

a3_range = -0.02 : 0.001 : 0.02;

lift = 0.5*pi*density*U^2*s^2*(a1)

drag = 0.5*pi*density*U^2*s^2*(a1^2 + 3.*(a3_range).^2);

set(0,'defaultaxesfontsize',14);

orient tall;
figure('Position',[10 100 500 800])
subplot(3,1,1)
plot(y, circ)
xlabel('Spanwise Position (y)'); ylabel('Circulation [\Gamma(y)]');
title('Spanwise Circulation Distribution')
legend('a3 = -0.02', 'a3 = -0.01', 'a3 = 0.00', 'a3 = 0.01', 'a3 = 0.02',...
    'location', 'EastOutside');
grid on;

subplot(3,1,2)
plot(y, w_star)
xlabel('Spanwise Position (y)'); ylabel('Induced Velocity [w*(y)]');
title('Spanwise Induced Velocity Distribution')
legend('a3 = -0.02', 'a3 = -0.01', 'a3 = 0.00', 'a3 = 0.01', 'a3 = 0.02',...
    'location', 'EastOutside');
grid on;

subplot(3,1,3)
plot(a3_range, drag)
xlabel('a3'); ylabel('Drag');
title('Drag as a function of a3')
grid on;

