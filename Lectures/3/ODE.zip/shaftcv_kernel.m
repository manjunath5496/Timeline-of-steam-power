function domega=shaftcv_kernel(t,w,J,f_v,f_c,T_s)

domega=(T_s-f_v*w-f_c*sign(w))/J;
