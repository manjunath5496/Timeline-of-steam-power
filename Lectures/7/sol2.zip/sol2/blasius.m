%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Blasius solution to boundary layer flow over a flat plate with no
% pressure gradient.
%
% Numerical solution and Taylor series solution to the non-linear differential 
% equation: f''' + (1/2)*f*f'' = 0 with boundary conditions 
% f(0) = 0, f'(0) = 0, f'(infinity) = 1
% eta = y * (U / nu*x)^(1/2)
%
% Created by Brenden Epps, bepps@mit.edu, 1/17/05
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% When I first created the program, I though I could change 
% f'(infinity) = 1 into a boundary condition for f"(0) by picking an f" and
% seeing what the resulting f'(infinity) was.  Naturally, I couldn't solve
% f' all the way out to infinity, so I chose eta_final to be 10, 100, and
% 1000, and looked at how the solution changed.  I saw for delta_eta small
% enough, like 0.0001, then eta_final = 10 was good enough.  I determined
% that f"(0) = 0.332 yielded f'(eta_final) ~ 1, and checked that figure
% against the known solution.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear;
eta_initial = 0;      % eta_initial always equals zero  
eta_final   = 10;     % we will vary eta_final to see how the curve changes
delta_eta   = 0.0010; % we will vary delta_eta to see how the curve changes
n           = (eta_final-eta_initial)/delta_eta;

%%%%%%%%%%%  INITIAL CONDITIONS  %%%%%%%%%%%%%%%%%%%%%%%%
eta(1) = eta_initial;
f(1)     = 0;
f_p(1)   = 0;
f_pp(1)  = 0.332; % we will vary this to see how the curve changes 
% We know that f_p(infinity) = 1, so by varying f_pp(0), we should be able
% to get the f_p curve to asymptote to 1.  (I started with f_pp(0)=1,
% which was too high, then 0.5, 0.4, and so on, until 0.332 finally gave us
% 1.
%%%%%%%%%%%%  END: INITIAL CONDITIONS  %%%%%%%%%%%%%%%%%%%

for i = 2: n, 
    eta(i)    = delta_eta * i;
    
    f_ppp(i)  = (-1/2)*f(i-1)*f_pp(i-1);
    f_pp(i)   = f_pp(i-1) + f_ppp(i-1)*delta_eta;
    f_p(i)    = f_p(i-1)  + f_pp(i-1) *delta_eta;
    f(i)      = f(i-1)    + f_p(i-1)  *delta_eta;

end;


plot(f_p,eta)
title('Blasius Solution: flow over a flat plate','Fontsize',16)
xlabel('Non-dimensional velocity   {u/U}','Fontsize',14)
ylabel('Non-dimensional height   {\eta = y / (\nu x/U)^{1/2}}','Fontsize',14)
