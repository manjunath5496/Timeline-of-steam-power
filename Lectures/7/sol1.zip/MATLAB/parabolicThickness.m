%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  ellipticalThickness.m                                               %%
%%  Propeller Parabolic Thickness Profile Generator                     %%
%%  M Jordan Stanway                                                    %%
%%  2.23 - Hydrofoils & Propellers                                      %%
%%  squall@mit.edu                                                      %%
%%  Created: 16 February 2006                                           %%
%%  Last Updated: 18 February 2006                                      %%
%%                                                                      %%
%%  All rights reserved                                                 %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Uses parabolic thickness form

function [t] = thickness(T0_D_i,C_D_i,D,numPoints);
% create non-dimensional t(x) given T0_D_i for a particular cross-section
T0 = T0_D_i * D;
C = C_D_i*D;
x = C*[-0.5:(1/numPoints):0.5];
for ct = 1:length(x);
    t(ct) = T0 * (1-((2*x(ct))/C).^2);
end