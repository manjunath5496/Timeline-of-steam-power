function out=djndx(n,x)

out=jn(n-1,x)-(n+1)*jn(n,x)/x;
