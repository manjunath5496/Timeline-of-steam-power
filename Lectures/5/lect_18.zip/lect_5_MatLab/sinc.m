function[ss]=sinc(x)
     xx=max(abs(x),1e-15);
     ss=sin(xx)./xx;
