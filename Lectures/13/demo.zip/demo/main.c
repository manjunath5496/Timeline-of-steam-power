#include <msp430x22x4.h>

#define START 0xFF       // radio packet start byte

#define TECHNO 955
#define GUITAR 1470
#define JAZZ 825


int main( void )
{
  // Stop watchdog timer to prevent time out reset
  WDTCTL = WDTPW + WDTHOLD;

  // 16MHz xtal clock setup: MCLK = 16MHz, SMCLK = 2MHz
  BCSCTL1 = XT2OFF | XTS;
  BCSCTL2 = SELM1 | SELM0 | SELS | DIVS1 | DIVS0;
  BCSCTL3 = LFXT1S1;
  _EINT();
  
  // Timer A setup
  TACTL = TASSEL0 | MC0;
  TACCR0 = 0x03FF;
  TACCTL1 = OUTMOD2 | OUTMOD1 | OUTMOD0;
  TACCTL2 = OUTMOD2 | OUTMOD1 | OUTMOD0;
	
  // Timer B setup
  TBCTL = TBSSEL0 | MC0;
  TBCCR0 = 0x03FF;
  TBCCTL1 = OUTMOD2 | OUTMOD1 | OUTMOD0;
  TBCCTL2 = OUTMOD2 | OUTMOD1 | OUTMOD0;
  
  // ADC setup, 3.3V reference
  ADC10CTL0 = MSC | ADC10ON;
  ADC10AE0 = BIT0 | BIT1 | BIT7;
  
  // UART setup, 19200kbps
  UCA0CTL0 = 0x00;
  UCA0CTL1 = UCSSEL0;
  UCA0BR0 = 833 & 0xFF; UCA0BR1 = 833 >> 8; UCA0MCTL = UCBRF_0 | UCBRS_2;
   
  // pin setup
  // P3DIR |= BIT4;
  // P3SEL |= BIT4 | BIT5;
  
  P1DIR |= BIT2 | BIT3 | BIT4 | BIT5 | BIT6 | BIT7;
  P1SEL |= BIT2 | BIT3;
  P4DIR |= BIT1 | BIT2;
  P4SEL |= BIT1 | BIT2;
       
  while(1)
  {
    TACCR1 = 0x0FF;
    TACCR2 = 0x0FF;
    TBCCR1 = 0x0FF;
    TBCCR2 = 0x0FF;
   
  }

}
