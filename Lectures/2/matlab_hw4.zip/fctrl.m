function o=fctrl(n)
%
% Problem 4.3:	Calculating the factorial of non-negative integer with function
%

% Define 0!=1
o=1; 

% Calculate factorial
% if n<1, Matlab skips 'for' loop (for n=0)
for i=1:n
    o=o*i; % n!=(n-1)!*n
end