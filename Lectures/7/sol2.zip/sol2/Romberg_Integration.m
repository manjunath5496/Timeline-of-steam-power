%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Romberg_Integration.m                                                  %
%  Numerical Integration function using the Romberg algorithm             %
%  Created by : Brenden  Epps,    bepps@mit.edu,  7 March 2007            %
%  2.23 - Hydrofoils & Propellers                                         %
%                                                                         %
%  All rights reserved                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Rhomberg_Integral = Romberg_Integration(fun,a,b,epsilon)

% Integration algorithm based on Romberg extrapolation
%
% f - string input for function y = f(x) (e.g. f = 'x.^6')
% a - lower limit of integration
% b - upper limit of integration
% epsilon - error acceptable (0.01 = 1% error) 
% R - Romberg integation matrix
%
% Example:
% Romberg_Integration('cos(x)',0,5,0.001)
%
% sin(6) == -0.2794
%
% NOTE: The trapezoidal sub-function is defined below, as copied from
% trapezoidal.m

%%%  The first column (K=1) is trapezoidal rule with L divisions  %%%%%%%%%
R(1,1) = trapezoidal(fun,a,b,1);
R(2,1) = trapezoidal(fun,a,b,2);

%%% Each interior R(L,K) for K > 1 is based on the Romberg algorithm  %%%%%
R(2,2) = (4*R(2,1) - R(1,1))/(4-1); 
    
L      = 2;

%%% If error is less than epsilon, then you are done  %%%%%%%%%%%%%%%%%%%%%
if abs( (R(L,L)-R(L,L-1))/R(L,L) ) < epsilon
    done = 1;
else
    done = 0;
end

%%%  Add rows onto the Romberg matrix until the integral converges  %%%%%%%
while done == 0
    L = L + 1;                      % Move one row down in the matrix
    
    R(L,1) = trapezoidal(fun,a,b,L);
   
    for K = 2 : L
        R(L,K) = (4^(K-1)*R(L,K-1) - R(L-1,K-1))/(4^(K-1)-1); 
    end
    
    if abs( (R(L,L)-R(L,L-1))/R(L,L) ) < epsilon
        done = 1;
    end

end
    
Rhomberg_Integral= R(L,L); 

%%%%  End  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Trapezoidal integration sub-function

function Trapezoidal_integral = trapezoidal(fun,a,b,n)

% Numerical integration using Trapezoidal Rule
% fun - string input for function y = f(x) (e.g. f = 'x.^6')
% a   - lower limit of integration
% b   - upper limit of integration
% n   - number of divisions
%
% Example: 
% trapezoidal('(1-x).*exp(-x)',0,5,10)
%
% Actual functions F = integral(f)
% F =    x .*exp(-x);
% f = (1-x).*exp(-x);

%%%%%%%%%%%%%  Numerical Integration        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delta_x = (b-a)/n;              % x spacing
x       = a : delta_x : b;      % x coordinates

f       = eval(fun);      % function to be integrated

%%%  Trapezoidal method  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i = 1:n
    area_of_each_trapezoid(i) = (1/2)*(f(i)+f(i+1))*delta_x;
end

Trapezoidal_integral = sum(area_of_each_trapezoid);

%%%%  End  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

