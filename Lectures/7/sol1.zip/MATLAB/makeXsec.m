%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  makeXsec.m                                                          %%
%%  Propeller Cross-Section Generator                                   %%
%%  M Jordan Stanway                                                    %%
%%  2.23 - Hydrofoils & Propellers                                      %%
%%  squall@mit.edu                                                      %%
%%  Created: 16 February 2006                                           %%
%%  Last Updated: 18 February 2006                                      %%
%%                                                                      %%
%%  All rights reserved                                                 %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% geometryFile is a .dat text file with non-dimensional values in columns:
% R/Ro  P/D     xs/d   Skew    C/D       Fo/c     To/D
%
% numPoints is a measure for the fineness of the reconstruction, it
% corresponds to the number of points calculated for each surface (top &
% bottom)

function [x_sec_X x_sec_Y] = makeXsecV2(geometryFile,section,numPoints);

%%% Read the propeller geometry file %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cd ../propParams
[r_R,P_D,x_rake,theta_skew,C_D,F0_C,T0_D] = textread(geometryFile,...
    '%f%f%f%f%f%f%f','headerlines',1);
cd ../MATLAB

%%% Get the dimensions for this section %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
F0_C_i = F0_C(section);
T0_D_i = T0_D(section);
C_D_i  = C_D(section);
D      = 1;      
C      = C_D_i*D;

%%% Generate thickness & camber profiles for this section %%%%%%%%%%%%%%%%%
[f,theta_dfdx] = parabolicCamber    (F0_C_i,C_D_i,D,numPoints);
t              = ellipticalThickness(T0_D_i,C_D_i,D,numPoints);

%%% Generate cartesian coordinates on the section's upper and lower surface
x             = [-0.5:(1/numPoints):0.5]*C;

xUpperSurface = x - t/2.*sin(theta_dfdx);
xLowerSurface = x + t/2.*sin(theta_dfdx);

yUpperSurface = f  + t/2.*cos(theta_dfdx);
yLowerSurface = f  - t/2.*cos(theta_dfdx);



% Generate a map of the whole section outline, beginning and ending on the
% trailing edge

x_sec_X = [xUpperSurface, fliplr(xLowerSurface)]';
x_sec_Y = [yUpperSurface, fliplr(yLowerSurface)]';