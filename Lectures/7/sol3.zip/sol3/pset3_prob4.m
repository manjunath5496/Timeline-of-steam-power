%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  pset3_prob4.m                                                          %
%  (see problem set 3)                                                    %
%                                                                         %
%  Created  by: John Stubblefield, jms93@mit.edu,  6 March 2007           %
%  Modified by: Brenden  Epps,     bepps@mit.edu, 22 March 2007           %
%  2.23 - Hydrofoils & Propellers                                         %
%                                                                         %
%  All rights reserved                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%  DESCRIPTION  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculates induced velocity at specifed control points for a given 
% circulation distribution.
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear, close all, %clc, 
% warning('off','all'),
set(0,'DefaultFigureWindowStyle','docked') 
set(0,'defaultaxesfontsize',14);
linewidth = 1.5;

%%% Set up parameters of the problem  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ct     = 0.45;   % [ ],      propeller thrust coefficient
Cd_v   = 0.008;  % [ ],      sectional viscous drag coefficient
J      = 0.9;    % [ ],      advance coefficient
Z      = 6;      % [ ],      number of blades
D      = 1;      % [m],      propeller diameter
R      = D/2;    % [m],      propeller radius
Vs     = 1;      % [m/s],    ship speed (m/s)
Va     = Vs;     % [m/s],    uniform axial inflow velocity (no swirl)
Vt     = 0;      % [m/s],    uniform tangential inflow velocity
rho    = 1000;   % [kg/m^3], density of water

chord       = [ 0   0   0   0   0   0   0   0   0    ]*R; % [m], chord lenght at each control point
rc          = [.2  .3  .4  .5  .6  .7  .8  .9  .975  ]*R; % [m], radius of control points                       
rv          = [.15 .25 .35 .45 .55 .65 .75 .85 .95  1]*R; % [m], radius of vortex points 
Gamma_nd    = [ 0  .2  .4  .6  .8 1.0  .7  .4  .1   0];   % [Gamma/Gamma0], Non-dim circulation distribution
drv         = diff(rv);                                   % [m], delta radius between vortex points
n_rc        = length(rc);
n_rv        = length(rv);

Gamma_hs_nd = Gamma_nd(1:n_rc) + diff(Gamma_nd).*((rc-rv(1:n_rc))./diff(rv));   % [Gamma/Gamma0], Non-dim circulation of horseshoes


%%% Compute propeller parameters 
N = Vs/(J*D);                % [rev/s], propeller rotation speed
w = 2*pi*N;                  % [rad/s], propeller angular velocity
T = Ct*0.5*rho*Vs^2*pi*R^2;  % [N],     thrust required

%%% Initialize unknowns
%
% We need to find Gamma0 in order to give the desired thrust.
Gamma0 = 0;                  % [m^2/s], max circulation
T_calc = 0;                  % [N],     calculated thrust, given Gamma0 
T_diff = T_calc - T;         % [N],     residual thrust to be made zero.

while T_diff < 0    
    Gamma0 = Gamma0 + .001;   % increment Gamma0
    
    Gamma_hs  = Gamma_hs_nd*Gamma0; % [m^2/s], circulation distribution

    %Inflow angle, in [deg]
    beta  = atand(Va ./ (w*rc + Vt));       
    betaW = atand(Va ./ (w*rv + Vt));   %IAW linear theory, betaW = beta at rv
    
    % Loop over vortices to calculate induced velocites, thrust, etc.
    Ustar_A = zeros(1,n_rc);      
    Ustar_T = zeros(1,n_rc);
    T_calc  = 0;
    Q_calc  = 0;
    
    for i_c = 1:n_rc          %loop thru all n_rc control points
                              %loop thru all n_rv horshoe vortices
            [Ubar_A,Ubar_T] = helix(rc(i_c),rv(1),Z,betaW(1));
            
            Ustar_A(i_c)    = Ustar_A(i_c) -  Gamma_hs(1)*Ubar_A; 
            Ustar_T(i_c)    = Ustar_T(i_c) -  Gamma_hs(1)*Ubar_T; 
        
        for i_v = 2:n_rv-1    
            [Ubar_A,Ubar_T] = helix(rc(i_c),rv(i_v),Z,betaW(i_v));
            
            Ustar_A(i_c)    = Ustar_A(i_c) - (Gamma_hs(i_v)-Gamma_hs(i_v-1))*Ubar_A; 
            Ustar_T(i_c)    = Ustar_T(i_c) - (Gamma_hs(i_v)-Gamma_hs(i_v-1))*Ubar_T; 
        end
        
            [Ubar_A,Ubar_T] = helix(rc(i_c),rv(n_rv),Z,betaW(n_rv));
            
            Ustar_A(i_c)    = Ustar_A(i_c) -  Gamma_hs(n_rv-1)*Ubar_A; 
            Ustar_T(i_c)    = Ustar_T(i_c) -  Gamma_hs(n_rv-1)*Ubar_T; 
            
        betaI(i_c) = atand((Va+Ustar_A(i_c))/(w*rc(i_c)+Vt+Ustar_T(i_c)));
        
        Vstar(i_c) =  sqrt((Va+Ustar_A(i_c))^2 + (w*rc(i_c)+Vt+Ustar_T(i_c))^2);
        
        T_calc     = T_calc + Z*rho*Vstar(i_c)*abs(Gamma_hs(i_c))   *cosd(betaI(i_c))*drv(i_c)...
                            - Z*rho*0.5*Vstar(i_c)^2*chord(i_c)*Cd_v*sind(betaI(i_c))*drv(i_c);
                         
        Q_calc     = Q_calc + Z*rho*Vstar(i_c)*abs(Gamma_hs(i_c))   *sind(betaI(i_c))*rc(i_c)*drv(i_c)...
                            + Z*rho*0.5*Vstar(i_c)^2*chord(i_c)*Cd_v*cosd(betaI(i_c))*rc(i_c)*drv(i_c);        
    end
    
    T_diff = T_calc - T;
end

betz = tand(beta)./tand(betaI);


%****************************Data Tabulation*******************************

table = [rc'./R w.*rc'./Va Ustar_A'./Va Ustar_T'./Va Vstar'./Va beta' betaI' betz'];
fid=fopen('Output_Table_3_4.txt','w');
fprintf(fid,'r/R\t wr/Va\t ua*/Va\t ut*/Va\t V*/Va\t beta\t betaI\t tanB/tanBi\n');
fprintf(fid, '%4.3f\t  %4.2f\t %4.2f\t %4.2f\t %6.2f\t %4.2f\t %4.2f\t %3.3f\n', table');
fprintf(fid,'\n');
fprintf(fid,'Required shaft rotation = %3.2f rps\n',N);
fprintf(fid,'Thrust associated with given Ct of .45 is %5.2f N\n',T);
%%%% fprintf(fid,'At given value of Ct and Gamma0 = 1, thrust = %g N\n',T_calc);
fprintf(fid,'Calculated thrust = %5.2f N\n',T_calc);
fprintf(fid,'Thrust converges to the value associated with given Ct at Gamma0= %g\n',Gamma0);
fclose(fid);

%Print in display
fprintf('r/R\t wr/Va\t ua*/Va\t ut*/Va\t V*/Va\t beta\t betaI\t tanB/tanBi\n');
fprintf('%4.3f\t  %4.2f\t %4.2f\t %4.2f\t %6.2f\t %4.2f\t %4.2f\t %3.3f\n', table');
fprintf('\n');
fprintf('Required shaft rotation, N = %3.2f rps\n',N);
fprintf('Thrust associated with given Ct of .45 is %5.2f N\n',T);
fprintf('Calculated thrust = %5.2f N\n',T_calc);
fprintf('Thrust converges to the value associated with given Ct at Gamma0= %g\n',Gamma0);
%%%fprintf('At given value of Ct and Gamma0 = 1, thrust = %g N \n',T_calc);

