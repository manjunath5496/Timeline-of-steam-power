%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  pset3_prob3.m                                                          %
%  (see problem set 3)                                                    %
%                                                                         %
%  Created  by: John Beaver,    gamecock@mit.edu,  6 March 2007           %
%  Modified by: Brenden  Epps,     bepps@mit.edu, 22 March 2007           %
%  2.23 - Hydrofoils & Propellers                                         %
%                                                                         %
%  All rights reserved                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%  DESCRIPTION  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% An elliptical foil is to be designed to the following specifications:
% -	Aspect ratio A= 5.0
% -	Span = 1 meters
% -	U = 7 m/s
% -	Required Lift = 2500N
% -	Density = 1000 kg/m3
% -	No camber or twist
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
% a)    Find the overall Lift coefficient for this foil
% b)	Using Prandtl�s lifting line approximation find the angle of attack 
%       of this foil necessary to generate the required lift.
% c)	Find the induced drag coefficient and total induced drag
% d)	Estimate the total drag if Cd=0.008 
% e)	Describe qualitatively how the optimum foil shape would change
%       to minimize total drag (including viscous drag).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all;
clear all;
% clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The given data from the problem statement
A=5; 
span=1;   
U=7;    
Lift=2500;  
density=1000; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 3, Part A    
display('Problem 3, Part A')
display('Lift Coeffcient:')
S=span^2/A;

CL=Lift/(.5*density*U^2*S)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 3, Part B
display('Problem 3, Part B')
display('Angle of Attack (deg):')
alpha=(CL*(1+2/A))/(2*pi)*180/pi

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 3, Part C
display('Problem 3, Part C')
display('Drag Coeffcient :')
CD=CL^2/(pi*A)

display('Induced Drag Force (N):')
Dind=CD*.5*density*U^2*S

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Problem 3, Part D
display('Problem 3, Part D')
display('Total Drag (N):')
CDvis=.008;
c0=4*S/(pi*span);
y = sym('y');
c=int(c0*(sqrt(1-(2*y/span)^2)),y,-span/2,span/2);
c=.2;
Dviscous=span*CDvis*(.5*density*U^2*c);
Dtot=Dviscous+Dind
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

