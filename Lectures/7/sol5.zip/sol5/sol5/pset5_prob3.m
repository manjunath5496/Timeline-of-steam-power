% Pset #5, Problem 3

% Lc = 1/3;

Lc = 1/3*[0.1:0.01:1.9];
N = length(Lc);

Lv = 2/3;
c  = 1;

for i = 1:N

A = [-1/Lc(i),  1/(Lv-Lc(i));...
     -1/(Lv+Lc(i))    , -1/Lc(i)];
 
B = [-1; -1];


% A = [-1/Lc,  1/(Lv-Lc);...
%      -1/c , -1/Lc];
%  
% B = [-1; -1];


G(i,:) = linsolve(A,B);

CL_normalized(i) = 2*(G(i,1)+G(i,2));

end

I = min(find(CL_normalized > 1))


plot(Lc,CL_normalized,Lc(1:I),ones(1,I),'k--')
xlabel('Control point spacing, L_c','fontsize',14)
ylabel('C_L / 2*pi*sin(alpha)','fontsize',14)
title('Normalized lift coefficient versus L_c','fontsize',14)

hold on
plot([Lc(I), Lc(I)],[0,1],'k--')