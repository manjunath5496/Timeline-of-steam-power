%
% MATLAB script for plotting the directivity function for
% a rectangular, baffled piston with waves
%
% Parameters:
% k     Wavenumber
% rho   Density
% c     Speed of Sound
% lx,ly Dimensions of piston
% kx_0,ky_0 Wavenumbers of wavefield on piston
% d     Piston separation
% nd    Number of pistons
% qd    Array of piston strengths
% ang   Array heading (rad)
% 
clear
figure(1)
hold off
k=15
;
rho=1000;
c=1500;

%kx_0=0.5*k;
kx_0=0;
%kx_0=k
%ky_0=0.3*k;
ky_0=0;

lx=2.0;
ly=2.0;
l=max(lx,ly);

% Array definition
d=2.0;
nd=10;
ah=(nd-1)*d/2;
ang=30*pi/180;


xd=[-ah:d:ah]'*cos(ang)/(l/2);
yd=[-ah:d:ah]'*sin(ang)/(l/2);
qd=ones(length(xd),1).*hamming(length(xd));
%qd(2)=-1;

lxol=lx/l;
lyol=ly/l;

klh=k*l/2;
kx_0=kx_0*l/2;
ky_0=ky_0*l/2;

figure(1);
kxm=2*klh;
nkx=300;
dkx=2*kxm/(nkx-1);
x=[-kxm:dkx:kxm];
y=x;
o=ones(1,nkx);
kx=x' * o;
ky=(y' *o)';
ss=rho*k*c/(2*pi)*(sin(lxol*(kx-kx_0))./(lxol*(kx-kx_0))) .* (sin(lyol*(ky-ky_0))./(lyol*(ky-ky_0)));
%surfc(kx,ky,dba(ss));

    kx1=reshape(kx,1,size(kx,1)*size(kx,2));
    ky1=reshape(ky,1,size(ky,1)*size(ky,2));
    shd=qd'*exp(-i*(xd*kx1+yd*ky1));
    shd=reshape(shd,size(kx,1),size(kx,2));

ss=dba(ss.*shd);

wavei(ss',x,y)
shading('flat')
axis('equal')
b=xlabel('k_x L/2')
set(b,'FontSize',16);
b=ylabel('k_y L/2')
set(b,'FontSize',16);
tit=['kL/2 = ' num2str(klh) ' - L_x, L_y = ' num2str(lx) ', ' num2str(ly) ' - k_{x0}/k = ' num2str(kx_0/klh)]
b=title(tit);
set(b,'FontSize',20);

nphi=361;
dphi=2*pi/(nphi-1);
phi=[0:dphi:2*pi];
xx=klh*cos(phi);
yy=klh*sin(phi);
hold on
b=plot(xx,yy,'b');
set(b,'LineWidth',3);

figure(2) 
     nphi=361;
     dphi=2*pi/(nphi-1);
nth=181;
dth=0.5*pi/(nth-0.5);

phi=[0:dphi:(nphi-1)*dphi]' * ones(1,nth);
th=([dth/2:dth:pi/2]'*ones(1,nphi))';
kx=klh*sin(th).*cos(phi);
ky=klh*sin(th).*sin(phi);
ss=rho*k*c/(2*pi)*sinc(lxol*(kx-kx_0)) .* sinc(lyol*(ky-ky_0));

    kx1=reshape(kx,1,size(kx,1)*size(kx,2));
    ky1=reshape(ky,1,size(ky,1)*size(ky,2));
    shd=qd'*exp(-i*(xd*kx1+yd*ky1));
    shd=reshape(shd,size(kx,1),size(kx,2));

ss=dba(ss.*shd);

sm=max((max(ss))');
for i=1:size(ss,1)
     for j=1:size(ss,2)
     ss(i,j)=max(ss(i,j),sm-40.0)-(sm-40.0);
end
end

xx=ss.*sin(th).*cos(phi);
yy=ss.*sin(th).*sin(phi);
zz=ss.*cos(th);

surfl(xx,yy,zz);
colormap('copper');
shading('flat');
axis('equal');
tit=['kL/2 = ' num2str(klh) ' - L_x, L_y = ' num2str(lx) ', ' num2str(ly) ' - k_{x0}/k = ' num2str(kx_0/klh)]
b=title(tit);
set(b,'FontSize',20);


figure(3)
hold off
b=polar([pi/2-fliplr(th(1,:)) pi/2+th((nphi-1)/2+1,:)],[fliplr(ss(1,:)) ss((nphi-1)/2+1,:)]); 
set(b,'LineWidth',2)
tit=['kL/2 = ' num2str(klh) ' - L_x, L_y = ' num2str(lx) ', ' num2str(ly) ' - k_{x0}/k = ' num2str(kx_0/klh)]
b=title(tit);
set(b,'FontSize',20);


