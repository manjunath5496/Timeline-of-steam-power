%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  induced_velocity.m                                                     %
%  (see description below)                                                %
%                                                                         %
%  Created by : Chris Peterson, cjpeters@mit.edu, 2 March 2007            %
%  Created by : Keith Douglas,  kdouglas@mit.edu, 2 March 2007            %
%  Modified by: Brenden  Epps,     bepps@mit.edu, 7 March 2007            %
%  2.23 - Hydrofoils & Propellers                                         %
%                                                                         %
%  All rights reserved                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         % 
%   This function calculates the velocity a point in space, P, induced by %
%   a straight line vortex segment of strength gamma running from point   %
%   P1 to point P2.                                                       %                    
%                                                                         %
%   Note: Each point must be a vector in Cartesian space: P = [X Y Z].    %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [velocity_vector] = induced_velocity(P, P1, P2, gamma)

%%%  Convert in-put points into vector for calculation  %%%%%%%%%%%%%%%%%%%
r0 = P2 - P1;       %   vector from P1->P2
r1 = P  - P1;       %   vector from P1->P
r2 = P  - P2;       %   vector from P2->P

%%%  Calculation of velocity vector at point P due to vortex  %%%%%%%%%%%%%
if cross(r1,r2) == 0
    velocity_vector = 0;
else
    velocity_vector = (gamma/(4*pi)) * (norm(r0)/(norm(cross(r1,r2)))) ...
                     *(dot(r0,r1)/(norm(r0)*norm(r1)) - dot(r0,r2)/(norm(r0)*norm(r2)))...
                     * cross(r1,r2)/norm(cross(r1, r2));
end