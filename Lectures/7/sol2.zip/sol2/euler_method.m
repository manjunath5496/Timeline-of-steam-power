%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  euler_method.m                                                         %
%  Euler Method Example                                                   %
%  Created by : Brenden  Epps,    bepps@mit.edu,  23 February 2007        %
%  2.23 - Hydrofoils & Propellers                                         %
%                                                                         %
%  All rights reserved                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear, close all, clc,
set(0,'DefaultFigureWindowStyle','docked') 
set(0,'defaultaxesfontsize',14);
linewidth = 1.5;

%%%%%%%%%%%%%  Euler Method for Differential Equations    %%%%%%%%%%%%%%%%%
% 
% Solve dx/dt = -x numerically for t=[0,3].
% Initial condition: x(t=0) = 10

% %%% solve for a single value of delta_t %%%
% delta_t = 0.6;
% t       = 0:delta_t:3;
% n       = length(t);
% 
% x(1)    = 10; % initial condition
% 
% for i = 1:n-1
%     x_p(i) = -x(i);
%     x(i+1) = x(i) + x_p(i)*delta_t;
% end
% 
% T = 0:0.01:3;
% X = 10*exp(-T);
% 
% figure
% plot(T,X,'k',t,x,'sr','LineWidth',linewidth), 
% xlabel('t','Fontsize',14), ylabel('x(t)','Fontsize',14), 
% title('x(t)','Fontsize',16)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%     Solve for multiple values of delta_t    %%%%%%%%%%%%%%%%%%%%%%
delta_t = [0.6 0.3 0.05];
 
t = 0:delta_t(3):3;
X = 10*exp(-t);

figure, 
plot(t,X,'k','LineWidth',linewidth), 
xlabel('t','Fontsize',14), ylabel('x(t)','Fontsize',14),
title('x(t)','Fontsize',16)
hold on,

clear t,

for i_delta_t = 1:length(delta_t)
    n(i_delta_t)                = 1+(3-0)/delta_t(i_delta_t);
    t(i_delta_t,1:n(i_delta_t)) = 0:delta_t(i_delta_t):3;


    x(i_delta_t,1)    = 10; % initial condition

    for i = 1:n(i_delta_t)-1
        x_p(i_delta_t,i) = -x(i_delta_t,i);
        x(i_delta_t,i+1) = x(i_delta_t,i) + x_p(i_delta_t,i)*delta_t(i_delta_t);
    end
    
    plot(t(i_delta_t,1:n(i_delta_t)),x(i_delta_t,1:n(i_delta_t)),'r'), 
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

