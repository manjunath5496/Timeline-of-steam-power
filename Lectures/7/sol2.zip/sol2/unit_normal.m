%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  unit_normal.m                                                          %
%  This funciton finds the unit normal vector given three points in space.%
%  Created by : Chris Peterson, cjpeters@mit.edu, 2 March 2007            %
%  Modified by: Brenden  Epps,     bepps@mit.edu, 7 March 2007            %
%  2.23 - Hydrofoils & Propellers                                         %
%                                                                         %
%  All rights reserved                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Note: Each point must be a vector in Cartesian space: P = [X Y Z].

function unit_normal_vector = unit_normal(P1, P2, P3)
    V1 = P2-P1;                   % Vector from P1 to P2
    V2 = P3-P1;                   % Vector from P1 to P3
    
    normal_vector = cross(V1,V2);        % Vector normal to V1 and V2
    magnitude     = norm(normal_vector); % Length of normal vector
    
    unit_normal_vector = normal_vector/magnitude;  